# Notes hors ligne — prototype Android

Prototype natif Android en Java, avec stockage SQLite local et sans permission Internet.

## État actuel
- Création, modification et suppression de notes.
- Recherche dans les titres et le contenu.
- Stockage persistant local SQLite.
- Export JSON et import JSON.
- Interface française, thème clair simple.
- Aucune connexion, aucun compte, aucune synchronisation.
- Le manifeste ne déclare **pas** `android.permission.INTERNET`.

## Prérequis pour compiler
- JDK 17
- Android SDK avec Android SDK Platform 35
- Gradle 8.9 ou compatible avec Android Gradle Plugin 8.7.3

## Compiler sous Linux Mint
Depuis ce dossier :

```bash
java -version
./gradlew assembleDebug
```

Ce projet ne contient pas le wrapper Gradle. Si Gradle est installé localement :

```bash
gradle assembleDebug
```

L'APK de débogage sera créée dans :
`app/build/outputs/apk/debug/app-debug.apk`

Si Gradle n'est pas installé, installe le wrapper avec une version Gradle 8.9 puis exécute `./gradlew assembleDebug`.

## Installation sur un appareil connecté via ADB
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Sauvegarde
Dans le menu ⋯, choisis « Exporter les notes (JSON) ». Pour restaurer, choisis « Importer des notes (JSON) ». L'import ajoute les notes au contenu existant et ne l'écrase pas.

## Limites connues du prototype
- Ce n'est pas une copie de l'application Notion et il n'utilise aucun code ou ressource propriétaire de Notion.
- L'éditeur actuel est un éditeur de texte simple : pas encore de blocs riches, de pages imbriquées, de bases de données, de pièces jointes ni de mode sombre.
- Aucun test de compilation ou sur appareil n'a été exécuté dans l'environnement de génération. Compiler et tester avant utilisation.
- Les dépendances Gradle doivent être téléchargées lors de la première compilation. Après installation, l'application elle-même est conçue pour fonctionner hors ligne.
- L'application ne chiffre pas séparément la base SQLite ; la sécurité dépend notamment du verrouillage et du chiffrement de l'appareil Android.

## Prochaines étapes recommandées
1. Compiler et installer le prototype.
2. Tester la création, la modification, la recherche, l'export et l'import en mode avion.
3. Ajouter pages imbriquées et éditeur enrichi.
4. Ajouter vues de bases de données locales.
5. Ajouter thème sombre, modèles et pièces jointes.


## Compiler sans installer Android SDK sur son ordinateur

Le projet inclut un workflow GitHub Actions : `.github/workflows/android-apk.yml`.

1. Crée un dépôt GitHub vide.
2. Envoie le contenu de ce dossier dans le dépôt (pas le ZIP lui-même).
3. Ouvre l'onglet **Actions** du dépôt.
4. Lance **Build Android APK** avec **Run workflow**, ou attends la fin du build après un push.
5. Ouvre le run réussi et télécharge l'artifact `Notes-hors-ligne-debug-apk`.
6. Décompresse l'artifact pour obtenir `app-debug.apk`, puis transfère-le sur ton téléphone et installe-le.

Le build cloud nécessite un compte GitHub. Il compile le code source ; il n'analyse pas l'APK officielle de Notion. Le projet doit être vérifié après compilation.
