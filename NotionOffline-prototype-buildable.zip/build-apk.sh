#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
  echo "Erreur : Java est absent. Installe un JDK 17."
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "Erreur : Gradle est absent. Cette méthode locale nécessite Gradle 8.9."
  echo "Alternative : envoie le projet sur GitHub et lance l'action 'Build Android APK'."
  exit 1
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Erreur : Android SDK non configuré."
  echo "Définis ANDROID_HOME ou ANDROID_SDK_ROOT, puis installe Android SDK Platform 35."
  exit 1
fi
gradle --no-daemon assembleDebug
echo
echo "APK générée : app/build/outputs/apk/debug/app-debug.apk"
