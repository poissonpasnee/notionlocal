package fr.offline.notes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

final class NotesDb extends SQLiteOpenHelper {
    static final class Note {
        long id;
        String title;
        String body;
        long updatedAt;
        Note(long id, String title, String body, long updatedAt) {
            this.id = id; this.title = title; this.body = body; this.updatedAt = updatedAt;
        }
    }

    NotesDb(Context context) { super(context, "offline_notes.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, updated_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_notes_updated ON notes(updated_at DESC)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Future schema migrations must be added here without deleting user data.
    }

    long save(long id, String title, String body) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", title == null || title.trim().isEmpty() ? "Sans titre" : title.trim());
        values.put("body", body == null ? "" : body);
        values.put("updated_at", System.currentTimeMillis());
        if (id > 0) {
            db.update("notes", values, "id=?", new String[]{String.valueOf(id)});
            return id;
        }
        return db.insertOrThrow("notes", null, values);
    }

    void delete(long id) { getWritableDatabase().delete("notes", "id=?", new String[]{String.valueOf(id)}); }

    List<Note> list(String query) {
        List<Note> notes = new ArrayList<>();
        String q = "%" + (query == null ? "" : query.trim()) + "%";
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,title,body,updated_at FROM notes WHERE title LIKE ? OR body LIKE ? ORDER BY updated_at DESC",
                new String[]{q, q})) {
            while (c.moveToNext()) notes.add(new Note(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)));
        }
        return notes;
    }

    JSONArray exportJson() throws Exception {
        JSONArray array = new JSONArray();
        for (Note note : list("")) {
            JSONObject o = new JSONObject();
            o.put("title", note.title);
            o.put("body", note.body);
            o.put("updatedAt", note.updatedAt);
            array.put(o);
        }
        return array;
    }

    int importJson(JSONArray array) {
        SQLiteDatabase db = getWritableDatabase();
        int count = 0;
        db.beginTransaction();
        try {
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o == null) continue;
                ContentValues v = new ContentValues();
                v.put("title", o.optString("title", "Sans titre"));
                v.put("body", o.optString("body", ""));
                v.put("updated_at", System.currentTimeMillis());
                db.insert("notes", null, v);
                count++;
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        return count;
    }
}
