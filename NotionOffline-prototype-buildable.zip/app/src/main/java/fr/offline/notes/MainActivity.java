package fr.offline.notes;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity {
    private static final int EXPORT_REQUEST = 501;
    private static final int IMPORT_REQUEST = 502;
    private final int ink = Color.rgb(31, 35, 40);
    private final int muted = Color.rgb(104, 111, 120);
    private final int paper = Color.rgb(247, 247, 244);
    private final int cardColor = Color.WHITE;
    private NotesDb db;
    private LinearLayout root, notesContainer;
    private EditText search;
    private String query = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new NotesDb(this);
        buildUi();
        renderNotes();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(paper);
        root.setPadding(dp(18), dp(16), dp(18), dp(12));

        TextView eyebrow = text("ESPACE PERSONNEL", 11, muted, true);
        root.addView(eyebrow);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = text("Mes notes", 30, ink, true);
        titleRow.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        Button menu = smallButton("⋯");
        menu.setOnClickListener(v -> showMenu());
        titleRow.addView(menu);
        root.addView(titleRow);

        TextView subtitle = text("Tout reste sur cet appareil.", 14, muted, false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.bottomMargin = dp(16);
        root.addView(subtitle, subLp);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setHint("Rechercher dans les notes");
        search.setPadding(dp(14), 0, dp(14), 0);
        search.setBackground(roundRect(Color.WHITE, dp(14), Color.rgb(226, 228, 224)));
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(50)));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                query = s.toString(); renderNotes();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView section = text("RÉCENT", 11, muted, true);
        actions.addView(section, new LinearLayout.LayoutParams(0, dp(52), 1));
        Button add = smallButton("+ Nouvelle note");
        add.setTextColor(Color.WHITE);
        add.setBackground(roundRect(Color.rgb(36, 42, 37), dp(18), Color.TRANSPARENT));
        add.setOnClickListener(v -> editNote(null));
        actions.addView(add);
        root.addView(actions);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        notesContainer = new LinearLayout(this);
        notesContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(notesContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = text("Hors ligne · Stockage local · Sans compte", 11, muted, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, dp(36));
        root.addView(footer, footerLp);

        setContentView(root);
    }

    private void renderNotes() {
        if (notesContainer == null || db == null) return;
        notesContainer.removeAllViews();
        List<NotesDb.Note> notes = db.list(query);
        if (notes.isEmpty()) {
            LinearLayout empty = new LinearLayout(this);
            empty.setOrientation(LinearLayout.VERTICAL);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(48), dp(18), dp(48));
            TextView icon = text("✎", 32, muted, false);
            icon.setGravity(Gravity.CENTER);
            empty.addView(icon);
            TextView msg = text(query.isEmpty() ? "Aucune note pour le moment" : "Aucun résultat", 17, ink, true);
            msg.setGravity(Gravity.CENTER);
            empty.addView(msg);
            TextView detail = text(query.isEmpty() ? "Crée une note pour commencer." : "Essaie un autre terme de recherche.", 13, muted, false);
            detail.setGravity(Gravity.CENTER);
            empty.addView(detail);
            notesContainer.addView(empty);
            return;
        }
        for (NotesDb.Note note : notes) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(16), dp(14), dp(16), dp(14));
            card.setBackground(roundRect(cardColor, dp(17), Color.rgb(233, 234, 230)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(10);
            notesContainer.addView(card, lp);

            TextView title = text(note.title.isEmpty() ? "Sans titre" : note.title, 17, ink, true);
            card.addView(title);
            if (!note.body.trim().isEmpty()) {
                String preview = note.body.trim().replace('\n', ' ');
                if (preview.length() > 150) preview = preview.substring(0, 147) + "…";
                TextView body = text(preview, 14, muted, false);
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
                bp.topMargin = dp(6);
                card.addView(body, bp);
            }
            TextView date = text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date(note.updatedAt)), 11, muted, false);
            LinearLayout.LayoutParams dpLp = new LinearLayout.LayoutParams(-1, -2);
            dpLp.topMargin = dp(10);
            card.addView(date, dpLp);

            card.setOnClickListener(v -> editNote(note));
            card.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setTitle("Supprimer cette note ?")
                    .setMessage("Cette action est définitive.")
                    .setNegativeButton("Annuler", null)
                    .setPositiveButton("Supprimer", (d, w) -> { db.delete(note.id); renderNotes(); })
                    .show();
                return true;
            });
        }
    }

    private void editNote(NotesDb.Note note) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(8), dp(20), dp(4));
        EditText title = new EditText(this);
        title.setSingleLine(true);
        title.setTextSize(20);
        title.setHint("Titre");
        title.setText(note == null ? "" : note.title);
        form.addView(title, new LinearLayout.LayoutParams(-1, -2));
        EditText body = new EditText(this);
        body.setGravity(Gravity.TOP | Gravity.START);
        body.setTextSize(16);
        body.setHint("Écris quelque chose…");
        body.setMinLines(8);
        body.setMaxLines(16);
        body.setPadding(dp(2), dp(12), dp(2), dp(12));
        body.setText(note == null ? "" : note.body);
        form.addView(body, new LinearLayout.LayoutParams(-1, -2));

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle(note == null ? "Nouvelle note" : "Modifier la note")
            .setView(form)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer", null)
            .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String t = title.getText().toString().trim();
            String b = body.getText().toString();
            if (t.isEmpty() && b.trim().isEmpty()) {
                Toast.makeText(this, "Écris un titre ou du contenu.", Toast.LENGTH_SHORT).show();
                return;
            }
            db.save(note == null ? 0 : note.id, t, b);
            dialog.dismiss();
            renderNotes();
        }));
        dialog.show();
    }

    private void showMenu() {
        String[] options = {"Exporter les notes (JSON)", "Importer des notes (JSON)", "À propos"};
        new AlertDialog.Builder(this).setTitle("Options")
            .setItems(options, (d, which) -> {
                if (which == 0) {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, "notes-hors-ligne.json");
                    startActivityForResult(i, EXPORT_REQUEST);
                } else if (which == 1) {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    startActivityForResult(i, IMPORT_REQUEST);
                } else {
                    new AlertDialog.Builder(this).setTitle("Notes hors ligne")
                        .setMessage("Prototype local : aucune connexion réseau, aucun compte et aucune permission Internet. Les notes sont conservées dans une base SQLite sur cet appareil.")
                        .setPositiveButton("Fermer", null).show();
                }
            }).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == EXPORT_REQUEST) {
                JSONArray array = db.exportJson();
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(array.toString(2).getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this, "Export terminé.", Toast.LENGTH_SHORT).show();
            } else if (requestCode == IMPORT_REQUEST) {
                StringBuilder sb = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(uri);
                     BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String line; while ((line = reader.readLine()) != null) sb.append(line);
                }
                int count = db.importJson(new JSONArray(sb.toString()));
                renderNotes();
                Toast.makeText(this, count + " note(s) importée(s).", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Erreur : " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(13); b.setAllCaps(false);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setMinHeight(dp(42)); b.setMinimumHeight(dp(42));
        b.setBackground(roundRect(Color.WHITE, dp(16), Color.rgb(225, 227, 222)));
        return b;
    }

    private GradientDrawable roundRect(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        if (db != null) db.close();
        super.onDestroy();
    }
}
